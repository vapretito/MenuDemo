import Link from "next/link";
import { RestaurantAdminPanel } from "@/components/restaurant-admin-panel";
import styles from "./page.module.css";

export default function AdminPage() {
  return (
    <main className={styles.shell}>
      <header className={styles.topbar}>
        <div className={styles.brand}>
          <span className={styles.kicker}>Menui Admin</span>
          <strong>Restaurant workspace</strong>
        </div>
        <nav className={styles.links}>
          <Link href="/">Landing</Link>
          <Link href="/menu/subway">Menu demo</Link>
        </nav>
      </header>

      <RestaurantAdminPanel />
    </main>
  );
}
