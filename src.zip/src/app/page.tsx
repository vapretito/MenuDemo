import Link from "next/link";
import styles from "./page.module.css";
import { platformSnapshot } from "@/data/platform";

const money = new Intl.NumberFormat("es-AR", {
  style: "currency",
  currency: "ARS",
  maximumFractionDigits: 0,
});

export default function Home() {
  const featuredRestaurant = platformSnapshot.restaurants[0];
  const monthlyPrice = 20000;

  return (
    <main className={styles.page}>
      <section className={styles.heroSection}>
        <header className={styles.topbar}>
          <div className={styles.brand}>
            <span className={styles.brandMark}>M</span>
            <span className={styles.brandName}>MENUI</span>
          </div>

          <nav className={styles.nav}>
            <a href="#plataforma">Plataforma</a>
            <a href="#precios">Precios</a>
            <a href="#admin">Admin privado</a>
            <a href="#footer">Contacto</a>
          </nav>

          <div className={styles.topbarActions}>
            <Link className={styles.secondaryButton} href={`/menu/${featuredRestaurant.slug}`}>
              Ver el menu
            </Link>
            <a className={styles.primaryButton} href="#footer">
              Contacto
            </a>
          </div>
        </header>

        <div className={styles.heroGrid}>
          <div className={styles.heroCopy}>
            <span className={styles.eyebrow}>MENUI para restaurantes</span>
            <h1 className={styles.heroTitle}>Un menu digital simple, visual y facil de vender.</h1>
            <p className={styles.heroLead}>
              Plataforma para restaurantes con menu mobile, carrito directo a WhatsApp,
              panel de administracion privado y gestion simple por suscripcion mensual.
            </p>

            <div className={styles.heroActions}>
              <Link className={styles.primaryButton} href={`/menu/${featuredRestaurant.slug}`}>
                Ver menu demo
              </Link>
              <a className={styles.secondaryButton} href="mailto:hola@menui.oi">
                Contactar
              </a>
            </div>

            <div className={styles.heroNotes}>
              <span>14 dias gratis</span>
              <span>{money.format(monthlyPrice)} al mes</span>
              <span>Admin privado incluido</span>
            </div>

            <article className={styles.quoteCard}>
              <p>
                "La idea es simple: que el restaurante tenga una presencia moderna, un menu
                facil de actualizar y un flujo de pedido sin vueltas."
              </p>
              <strong>MENUI Platform</strong>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.logoSection}>
        <p>Ideal para restaurantes que quieren vender mejor desde su menu digital</p>
        <div className={styles.logoTicker}>
          <div className={styles.logoTrack}>
            <span>Menu mobile</span>
            <span>Pedidos por WhatsApp</span>
            <span>Admin privado</span>
            <span>Suscripcion mensual</span>
            <span>Multi restaurante</span>
            <span>Menu mobile</span>
            <span>Pedidos por WhatsApp</span>
            <span>Admin privado</span>
            <span>Suscripcion mensual</span>
            <span>Multi restaurante</span>
          </div>
        </div>
      </section>

      <section className={styles.infoSection} id="plataforma">
        <div className={styles.sectionIntro}>
          <span className={styles.eyebrowLight}>Plataforma</span>
          <h2>Todo lo importante de un menu digital, sin hacerlo complicado.</h2>
        </div>

        <div className={styles.featureGrid}>
          <article className={styles.featureCard}>
            <span>Menu publico</span>
            <h3>Una experiencia visual pensada para telefono</h3>
            <p>
              El cliente entra, mira categorias, agrega productos y hace el pedido de forma
              natural desde el celular.
            </p>
          </article>
          <article className={styles.featureCard}>
            <span>Carrito directo</span>
            <h3>Pedido sin checkout complejo</h3>
            <p>
              MENUI arma el mensaje y lo envia al WhatsApp del restaurante para acelerar la
              conversion.
            </p>
          </article>
          <article className={styles.featureCard}>
            <span>Multi local</span>
            <h3>Cada restaurante con su propio espacio</h3>
            <p>
              Subdominio, menu, configuracion y panel separados para operar varias marcas en
              una sola plataforma.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.pricingSection} id="precios">
        <div className={styles.sectionIntro}>
          <span className={styles.eyebrowLight}>Precios</span>
          <h2>Precio
          </h2>
        </div>

        <div className={styles.pricingLayout}>
          <article className={styles.pricingCardMain}>
            <span className={styles.planTag}>Plan MENUI</span>
            <strong>{money.format(monthlyPrice)}</strong>
            <p>por mes, por restaurante</p>
            <ul className={styles.pricingList}>
              <li>14 dias gratis para probar la plataforma</li>
              <li>Menu digital mobile-first</li>
              <li>Carrito y pedido directo a WhatsApp</li>
              <li>Panel admin privado</li>
              <li>Soporte para configuracion inicial</li>
            </ul>
          </article>

          <article className={styles.pricingCardSide}>
            <h3>Como funciona</h3>
            <p>Empiezas con una prueba gratis de 14 dias.</p>
            <p>Si te sirve, continuas por {money.format(monthlyPrice)} mensuales.</p>
            <p>No necesitas una app compleja ni desarrollo a medida para salir a vender.</p>
            <span className={styles.pricingNote}>Planes nuevos proximamente.</span>
          </article>
        </div>
      </section>

      <section className={styles.adminSection} id="admin">
        <div className={styles.sectionIntro}>
          <span className={styles.eyebrowLight}>Demo</span>
          <h2>Asi funciona MENUI.</h2>
        </div>

        <div className={styles.adminGrid}>
          <article className={styles.adminCard}>
            <h3>Vista demo del panel admin</h3>
            <p>
              Accede al panel de administracion desde cualquier dispositivo. Agregas
              productos con imagenes, descripciones y precios, eliminas items, creas
              categorias nuevas, activas promociones y cambias fotos en segundos, sin
              necesitar asistencia tecnica ni estar en el local.
            </p>
            <Link className={styles.primaryButton} href="/admin">
              Ver demo del admin
            </Link>
          </article>

          <article className={styles.adminCardMuted}>
            <h3>Demo publica del menu</h3>
            <p>
              En la demo publica ves como quedaria la experiencia del cliente final.
              El menu es 100% personalizable en la estetica: colores, fotos, categorias,
              destacados y estilo visual para adaptarlo a la identidad de cada restaurante.
            </p>
            <Link className={styles.secondaryButton} href={`/menu/${featuredRestaurant.slug}`}>
              Ver demo publica
            </Link>
          </article>
        </div>
      </section>

      <section className={styles.contactBand}>
        <section className={styles.contactSection} id="contacto">
          <div className={styles.sectionIntro}>
            <span className={styles.eyebrowLight}>Contacto</span>
            <h2>Hablemos por WhatsApp</h2>
          </div>

          <div className={styles.contactLayout}>
            <article className={styles.contactCardMain}>
              <h3>Contacto directo</h3>
              <p>
                Si quieres ver una demo, consultar precios o pedir una version adaptada a tu
                restaurante, puedes escribirme directo por WhatsApp.
              </p>
              <a
                className={styles.contactButton}
                href="https://wa.me/543516641124?text=Hola%2C%20quiero%20informacion%20sobre%20MENUI"
              >
                Enviar mensaje por WhatsApp
              </a>
            </article>
          </div>
        </section>

        <footer className={styles.footer} id="footer">
          <div className={styles.footerBrand}>
            <span className={styles.brandMark}>M</span>
            <div>
              <strong>MENUI</strong>
              <p>Plataforma de menu digital para restaurantes con carrito y admin privado.</p>
            </div>
          </div>

          <div className={styles.footerColumns}>
            <div>
              <h4>Producto</h4>
              <a href="#plataforma">Plataforma</a>
              <a href="#precios">Precios</a>
              <Link href={`/menu/${featuredRestaurant.slug}`}>Ver menu demo</Link>
            </div>
            <div>
              <h4>Accesos</h4>
              <Link href="/backoffice/login">Login admin privado</Link>
              <Link href="/admin">Panel restaurante</Link>
              <Link href="/superadmin">Superadmin</Link>
            </div>
            <div>
              <h4>Contacto</h4>
              <a href="mailto:hola@menui.oi">hola@menui.oi</a>
              <a href="https://wa.me/543516641124">WhatsApp</a>
              <span>14 dias gratis y luego {money.format(monthlyPrice)} / mes</span>
            </div>
          </div>
        </footer>
      </section>

      <div className={styles.mobileBottomBar}>
        <Link className={styles.secondaryButton} href={`/menu/${featuredRestaurant.slug}`}>
          Ver el menu
        </Link>
        <a className={styles.primaryButton} href="#contacto">
          Contacto
        </a>
      </div>

      <a
        className={styles.whatsappFloat}
        href="https://wa.me/543516641124?text=Hola%2C%20quiero%20informacion%20sobre%20MENUI"
        aria-label="Escribirme por WhatsApp"
      >
        WhatsApp
      </a>
    </main>
  );
}
